<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="shortcut icon" href="img/coforward.ico" />
<title>TEST Form Action Page</title>
<style type="text/css">
	#formValue{
		margin-left:50px;
		margin-right:50px;
		padding:20px;
		font-size:20px;
		color:#00F;
		background:#C8C8C8;
		border-radius:20px;
	}
</style>
</head>

<body>
<h1>TEST Form Action Page</h1>
<h2>폼으로 부터 넘겨진 값은 다음과 같습니다. </h2>
<div id="formValue">
	<?php var_dump($_REQUEST); ?>
</div>

</body>
</html>
